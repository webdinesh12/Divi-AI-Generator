<?php
if (!defined('ABSPATH')) exit;

class AIDiviTools
{
    const SELECTED_PLATFORM = 'selected_platform';
    const OPT_KEY = 'google_gemini_api_key';
    const OPEN_AI_KEY = 'open_ai_api_key';
    const OPT_MODEL = 'google_gemini_model_name';
    const OPEN_AI_MODEL = 'open_ai_model';

    public function __construct()
    {
        // Admin Menu
        add_action('admin_menu', [$this, 'add_tools_submenu']);

        // Save settings
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function register_settings()
    {
        register_setting(
            'ai_divi_tools_group',
            self::OPT_KEY,
            ['sanitize_callback' => 'sanitize_text_field']
        );
        register_setting(
            'ai_divi_tools_group',
            self::OPT_MODEL,
            ['sanitize_callback' => 'sanitize_text_field']
        );
        register_setting(
            'ai_divi_tools_group',
            self::OPEN_AI_KEY,
            ['sanitize_callback' => 'sanitize_text_field']
        );
        register_setting(
            'ai_divi_tools_group',
            self::OPEN_AI_MODEL,
            ['sanitize_callback' => 'sanitize_text_field']
        );
        register_setting(
            'ai_divi_tools_group',
            self::SELECTED_PLATFORM,
            ['sanitize_callback' => 'sanitize_text_field']
        );
    }


    public function add_tools_submenu()
    {
        add_submenu_page(
            'ai-divi',
            'AI → Divi Tools',
            'Tools',
            'edit_pages',
            'ai-divi-tools',
            [$this, 'render_tools_page']
        );
    }

    public function render_tools_page()
    {
        $api_key = get_option(self::OPT_KEY, '');
        $gemini_model = get_option(self::OPT_MODEL, 'gemini-2.5-flash');
        $open_ai_api_key = get_option(self::OPEN_AI_KEY, '');
        $open_ai_model = get_option(self::OPEN_AI_MODEL, 'gpt-5');
        $selected_platform = get_option(self::SELECTED_PLATFORM, 'gemini');

        echo '<div class="wrap">';
        echo '<h1>AI → Divi Tools</h1>';
        echo '<p>Enter your Google Gemini API Key:</p>';

        echo '<form method="post" action="options.php">';

        settings_fields('ai_divi_tools_group');
        do_settings_sections('ai_divi_tools_group');

        echo '
            <table class="form-table">
                <tr>
                    <th scope="row">Select Platform</th>
                    <td>
                        <select id="selected_platform_select" name="' . self::SELECTED_PLATFORM . '">
                            <option value="open_ai" ' . ($selected_platform == 'open_ai' ? 'selected' : '') . '>GPT - Open AI </option>
                            <option value="gemini" ' . ($selected_platform == 'gemini' ? 'selected' : '') . '>Gemini - Google</option>
                        </select>
                    </td>
                </tr>                
                <tr class="open_ai_tr show_by_select_change" style="display: none;">
                    <th scope="row">OPEN AI API Key</th>
                    <td>
                        <input type="text" name="' . self::OPEN_AI_KEY . '" 
                               value="' . esc_attr($open_ai_api_key) . '" 
                               class="regular-text" style="width: 400px;">
                    </td>
                </tr>
                <tr class="open_ai_tr show_by_select_change" style="display: none;">
                    <th scope="row">OPEN AI Model Name</th>
                    <td>
                        <input type="text" name="' . self::OPEN_AI_MODEL . '" 
                               value="' . esc_attr($open_ai_model) . '" 
                               class="regular-text" style="width: 400px;">
                    </td>
                </tr>
                <tr class="gemini_tr show_by_select_change" style="display: none;">
                    <th scope="row">Gemini API Key</th>
                    <td>
                        <input type="text" name="' . self::OPT_KEY . '" 
                               value="' . esc_attr($api_key) . '" 
                               class="regular-text" style="width: 400px;">
                    </td>
                </tr>
                <tr class="gemini_tr show_by_select_change" style="display: none;">
                    <th scope="row">Gemini Model Name</th>
                    <td>
                        <input type="text" name="' . self::OPT_MODEL . '" 
                               value="' . esc_attr($gemini_model) . '" 
                               class="regular-text" style="width: 400px;">
                               <p>eg: gemini-2.5-flash, gemini-2.5-flash-lite, gemini-2.5-pro</p>
                    </td>
                </tr>
            </table>
            <script>
            document.addEventListener("DOMContentLoaded", function() {
                const selectElement = document.getElementById("selected_platform_select");

                selectElement.addEventListener("change", function() {
                    showTr();
                });

                showTr();

                function showTr() {
                    const val = selectElement.value;

                    const hideElements = document.querySelectorAll(".show_by_select_change");
                    hideElements.forEach(el => {
                        el.style.display = "none";
                    });

                    // Show elements with class `${val}_tr`
                    const showElements = document.querySelectorAll(`.${val}_tr`);
                    showElements.forEach(el => {
                        el.style.display = "";
                    });
                }
            });
        </script>
            ';
        submit_button('Save API Key');

        echo '</form>';
        echo '</div>';
    }
}
