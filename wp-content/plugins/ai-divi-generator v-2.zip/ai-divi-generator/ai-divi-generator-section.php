<?php
if (!defined('ABSPATH')) exit;

class AIDiviTools
{
    const OPT_KEY = 'google_gemini_api_key';

    public function __construct()
    {
        // Admin Menu
        add_action('admin_menu', [$this, 'add_tools_submenu']);

        // Save settings
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function register_settings()
    {
        register_setting(
            'ai_divi_tools_group',
            self::OPT_KEY,
            ['sanitize_callback' => 'sanitize_text_field']
        );
    }

    public function add_tools_submenu()
    {
        add_submenu_page(
            'ai-divi',
            'AI → Divi Tools',
            'Tools',
            'edit_pages',
            'ai-divi-tools',
            [$this, 'render_tools_page']
        );
    }

    public function render_tools_page()
    {
        $api_key = get_option(self::OPT_KEY, '');

        echo '<div class="wrap">';
        echo '<h1>AI → Divi Tools</h1>';
        echo '<p>Enter your Google Gemini API Key:</p>';

        echo '<form method="post" action="options.php">';

        settings_fields('ai_divi_tools_group');
        do_settings_sections('ai_divi_tools_group');

        echo '
            <table class="form-table">
                <tr>
                    <th scope="row">Gemini API Key</th>
                    <td>
                        <input type="text" name="' . self::OPT_KEY . '" 
                               value="' . esc_attr($api_key) . '" 
                               class="regular-text" style="width: 400px;">
                    </td>
                </tr>
            </table>
            ';

        submit_button('Save API Key');

        echo '</form>';
        echo '</div>';
    }
}
